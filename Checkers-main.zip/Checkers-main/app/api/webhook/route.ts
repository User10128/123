import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import admin from 'firebase-admin';

let stripe: Stripe | null = null;

function getStripe() {
  if (!stripe) {
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key) {
      throw new Error('STRIPE_SECRET_KEY is required');
    }
    stripe = new Stripe(key);
  }
  return stripe;
}

function getDb() {
  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.applicationDefault(),
    });
  }
  return admin.firestore();
}

export async function POST(req: Request) {
  const body = await req.text();
  const signature = req.headers.get('stripe-signature')!;
  const stripeClient = getStripe();
  const db = getDb();

  let event: Stripe.Event;

  try {
    event = stripeClient.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err: any) {
    console.error('Webhook signature verification failed:', err.message);
    return NextResponse.json({ error: err.message }, { status: 400 });
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session;
    const uid = session.metadata?.uid;

    if (uid) {
      const appId = process.env.NEXT_PUBLIC_APP_ID || 'checkers-app';
      const docRef = db.doc(`artifacts/${appId}/public/data/profiles/${uid}`);
      
      await docRef.set({ isPro: true }, { merge: true });
      console.log(`User ${uid} upgraded to Pro!`);
    }
  }

  return NextResponse.json({ received: true });
}
